package com.codingdojo.templatelogreg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemplatelogregApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemplatelogregApplication.class, args);
	}
}
